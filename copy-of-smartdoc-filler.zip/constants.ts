
export const AUTH_CREDENTIALS = {
  username: 'LaspirAd',
  password: 'LaspirAD191'
};

export const PLACEHOLDER_REGEX = /\{([a-zA-Z0-9_]+)\}/g;

// The hardcoded API key for the application
export const API_KEY = "TEST";
